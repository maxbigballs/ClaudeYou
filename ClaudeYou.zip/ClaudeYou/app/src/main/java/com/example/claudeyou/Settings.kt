package com.example.claudeyou

import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Настройки приложения. Хранятся в SharedPreferences, наблюдаются Compose. */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Цвета из системных обоев (Android 12+). */
    var dynamic by mutableStateOf(p.getBoolean("dynamic", Build.VERSION.SDK_INT >= 31))
    /** Свой акцентный оттенок 0..360. */
    var hue by mutableFloatStateOf(p.getFloat("hue", 265f))
    /** 0 — как в системе, 1 — светлая, 2 — тёмная. */
    var mode by mutableIntStateOf(p.getInt("mode", 0))
    /** Масштаб текста на сайте, %. */
    var zoom by mutableIntStateOf(p.getInt("zoom", 100))
    /** Подмешивать свои стили в страницу. */
    var inject by mutableStateOf(p.getBoolean("inject", true))

    fun save() {
        p.edit()
            .putBoolean("dynamic", dynamic).putFloat("hue", hue).putInt("mode", mode)
            .putInt("zoom", zoom).putBoolean("inject", inject).apply()
    }

    fun applyNightMode() {
        AppCompatDelegate.setDefaultNightMode(
            when (mode) {
                1 -> AppCompatDelegate.MODE_NIGHT_NO
                2 -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        )
    }
}
