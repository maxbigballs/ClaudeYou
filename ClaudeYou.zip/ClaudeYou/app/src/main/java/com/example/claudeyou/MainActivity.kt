package com.example.claudeyou

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

private const val HOME = "https://claude.ai/"
private val ALLOWED = listOf(
    "claude.ai", "anthropic.com", "google.com", "gstatic.com", "googleusercontent.com",
    "apple.com", "stripe.com", "cloudflare.com"
)

class MainActivity : AppCompatActivity() {
    var fileCb: ValueCallback<Array<Uri>>? = null
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    fun pickFiles(intent: Intent): Boolean = try { chooser.launch(intent); true } catch (e: Exception) { false }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val s = Settings(this)
        s.applyNightMode()
        setContent { App(s, this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(s: Settings, act: MainActivity) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = if (s.dynamic && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else seedScheme(s.hue, dark)

    MaterialTheme(colorScheme = scheme) {
        var web by remember { mutableStateOf<WebView?>(null) }
        var sheet by remember { mutableStateOf(false) }
        var progress by remember { mutableIntStateOf(100) }
        var canBack by remember { mutableStateOf(false) }
        val accent = scheme.primary.hex()
        val css = if (s.inject)
            ":root{accent-color:$accent}::selection{background:${accent}55}html{scrollbar-width:none}" else ""

        BackHandler(enabled = canBack) { web?.goBack() }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.surface,
            topBar = {
                TopAppBar(
                    title = { Text("Claude") },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface),
                    actions = {
                        IconButton(onClick = { web?.reload() }) { Icon(Icons.Default.Refresh, "Обновить") }
                        IconButton(onClick = { sheet = true }) { Icon(Icons.Default.Settings, "Настройки") }
                    }
                )
            }
        ) { pad ->
            Box(Modifier.padding(pad).imePadding().fillMaxSize()) {
                ClaudeWeb(act, s.zoom, css, { web = it }, { progress = it }, { canBack = it })
                if (progress < 100) LinearProgressIndicator(
                    progress = { progress / 100f }, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
                )
            }
        }

        if (sheet) ModalBottomSheet(onDismissRequest = { sheet = false }) { SettingsPanel(s) }
    }
}

private fun injectJs(css: String) =
    "(function(){var s=document.getElementById('cy-style');if(!s){s=document.createElement('style');" +
    "s.id='cy-style';(document.head||document.documentElement).appendChild(s)}s.textContent='" + css + "'})()"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ClaudeWeb(
    act: MainActivity, zoom: Int, css: String,
    onWeb: (WebView) -> Unit, onProgress: (Int) -> Unit, onCanBack: (Boolean) -> Unit,
) {
    AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            // Убираем маркер WebView из User-Agent: так вход проходит чаще.
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            cm.setAcceptThirdPartyCookies(this, true)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                    val host = r.url.host ?: return false
                    if (ALLOWED.any { host == it || host.endsWith(".$it") }) return false
                    return try {
                        act.startActivity(Intent(Intent.ACTION_VIEW, r.url)); true
                    } catch (e: Exception) { false }
                }
                override fun onPageFinished(v: WebView, url: String?) {
                    v.evaluateJavascript(injectJs((v.tag as? String) ?: ""), null)
                }
                override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) {
                    onCanBack(v.canGoBack())
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(v: WebView, newProgress: Int) = onProgress(newProgress)
                override fun onShowFileChooser(
                    v: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
                ): Boolean {
                    act.fileCb?.onReceiveValue(null)
                    act.fileCb = cb
                    if (!act.pickFiles(params.createIntent())) { act.fileCb = null; cb.onReceiveValue(null) }
                    return true
                }
            }
            tag = css
            onWeb(this)
            loadUrl(HOME)
        }
    }, update = { wv ->
        wv.settings.textZoom = zoom
        wv.tag = css
        wv.evaluateJavascript(injectJs(css), null)
    })
}

private val SEEDS = listOf(265f, 205f, 150f, 25f, 340f, 50f, 175f)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsPanel(s: Settings) {
    val dark = isSystemInDarkTheme()
    val canDynamic = Build.VERSION.SDK_INT >= 31
    val useCustom = !(s.dynamic && canDynamic)
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Оформление", style = MaterialTheme.typography.headlineSmall)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Цвета из обоев", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (canDynamic) "Системные динамические цвета" else "Нужен Android 12 или новее",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = s.dynamic && canDynamic, enabled = canDynamic,
                onCheckedChange = { s.dynamic = it; s.save() })
        }

        if (useCustom) {
            Text("Акцентный цвет", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SEEDS.forEach { h ->
                    val sel = kotlin.math.abs(s.hue - h) < 1f
                    Box(
                        Modifier.size(40.dp).clip(CircleShape)
                            .background(seedScheme(h, dark).primary)
                            .then(if (sel) Modifier.background(Color.Transparent) else Modifier)
                            .clickable { s.hue = h; s.save() }
                    ) {
                        if (sel) Text("✓", Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.surface)
                    }
                }
            }
            Slider(value = s.hue, onValueChange = { s.hue = it }, onValueChangeFinished = { s.save() },
                valueRange = 0f..360f)
        }

        Text("Тема", style = MaterialTheme.typography.titleMedium)
        val labels = listOf("Система", "Светлая", "Тёмная")
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, l ->
                SegmentedButton(
                    selected = s.mode == i,
                    onClick = { s.mode = i; s.save(); s.applyNightMode() },
                    shape = SegmentedButtonDefaults.itemShape(i, labels.size)
                ) { Text(l) }
            }
        }

        Text("Размер текста на сайте: ${s.zoom}%", style = MaterialTheme.typography.titleMedium)
        Slider(value = s.zoom.toFloat(), onValueChange = { s.zoom = it.toInt() },
            onValueChangeFinished = { s.save() }, valueRange = 80f..160f, steps = 7)

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Подкрасить сайт", style = MaterialTheme.typography.titleMedium)
                Text("Экспериментально: цвет выделения и акцент на странице",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = s.inject, onCheckedChange = { s.inject = it; s.save() })
        }
    }
}
