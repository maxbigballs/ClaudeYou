package com.example.claudeyou

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs

/** Тон палитры: оттенок h, насыщенность s (0..100), светлота t (0..100). */
private fun tone(h: Float, s: Float, t: Float): Color {
    val k = s * (1f - abs(t - 50f) / 100f * 0.9f)
    return Color.hsl(((h % 360f) + 360f) % 360f, (k / 100f).coerceIn(0f, 1f), t / 100f)
}

/** Схема в духе Material You, построенная от одного оттенка (для Android до 12 и для своего цвета). */
fun seedScheme(h: Float, dark: Boolean): ColorScheme {
    fun p(t: Float) = tone(h, 75f, t)
    fun s(t: Float) = tone(h, 22f, t)
    fun t3(t: Float) = tone(h + 60f, 40f, t)
    fun n(t: Float) = tone(h, 14f, t)
    fun nv(t: Float) = tone(h, 10f, t)
    return if (dark) darkColorScheme(
        primary = p(80f), onPrimary = p(20f), primaryContainer = p(30f), onPrimaryContainer = p(90f),
        secondary = s(80f), onSecondary = s(20f), secondaryContainer = s(30f), onSecondaryContainer = s(90f),
        tertiary = t3(80f), onTertiary = t3(20f), tertiaryContainer = t3(30f), onTertiaryContainer = t3(90f),
        background = n(7f), onBackground = n(90f), surface = n(7f), onSurface = n(90f),
        surfaceVariant = nv(30f), onSurfaceVariant = nv(80f), outline = nv(60f), outlineVariant = nv(30f),
        surfaceContainerLowest = n(5f), surfaceContainerLow = n(10f), surfaceContainer = n(12f),
        surfaceContainerHigh = n(17f), surfaceContainerHighest = n(22f),
    ) else lightColorScheme(
        primary = p(40f), onPrimary = Color.White, primaryContainer = p(90f), onPrimaryContainer = p(10f),
        secondary = s(40f), onSecondary = Color.White, secondaryContainer = s(90f), onSecondaryContainer = s(10f),
        tertiary = t3(40f), onTertiary = Color.White, tertiaryContainer = t3(90f), onTertiaryContainer = t3(10f),
        background = n(98f), onBackground = n(10f), surface = n(98f), onSurface = n(10f),
        surfaceVariant = nv(90f), onSurfaceVariant = nv(30f), outline = nv(50f), outlineVariant = nv(80f),
        surfaceContainerLowest = n(100f), surfaceContainerLow = n(96f), surfaceContainer = n(94f),
        surfaceContainerHigh = n(92f), surfaceContainerHighest = n(90f),
    )
}

fun Color.hex(): String = String.format("#%06X", 0xFFFFFF and toArgb())
